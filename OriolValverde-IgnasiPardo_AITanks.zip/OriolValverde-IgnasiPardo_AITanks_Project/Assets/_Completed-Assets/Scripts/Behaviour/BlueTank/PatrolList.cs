using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PatrolList : MonoBehaviour
{
    public GameObject[] patrolList;
  
    void Update()
    {
        
    }
}
