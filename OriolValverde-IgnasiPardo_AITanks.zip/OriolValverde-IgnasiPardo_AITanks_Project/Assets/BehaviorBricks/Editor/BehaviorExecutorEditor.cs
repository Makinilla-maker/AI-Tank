﻿using UnityEngine;
using System.Collections;
using UnityEditor;

[CustomEditor(typeof(BehaviorExecutor))]
public class BehaviorExecutorEditor : BBUnity.InternalBehaviorExecutorEditor
{
}
